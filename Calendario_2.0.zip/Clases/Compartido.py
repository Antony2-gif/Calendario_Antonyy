from View.Agregar import Ui_MainWindow
#Configuramos el Comboxs
def ComBoxs():
    opciones = ("Am","Pm")
    return opciones
