#!/bin/bash

python3 app.py

exit
